package Core;

public class EmptyTile extends Entity{
    public EmptyTile(int x, int y) {
        super(x, y);
    }
}
