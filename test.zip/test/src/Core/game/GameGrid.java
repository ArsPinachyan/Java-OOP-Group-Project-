package Core.game;

import Core.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameGrid extends JFrame implements KeyListener {
    private static final int ROWS = 10;
    private static final int COLS = 10;
    private JPanel[][] grid = new JPanel[ROWS][COLS];
    private boolean[][] isWall = new boolean[ROWS][COLS];

    private int playerRow = ROWS / 2;
    private int playerCol = COLS / 2;

    public GameGrid() {
        setTitle("Grid Game");
        setSize(600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(ROWS, COLS));
        addKeyListener(this);
        setFocusable(true);

        initializeGrid();
        drawGrid();

        setVisible(true);


    }
    private void initializeGrid() {

        // Create grid tiles
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                JPanel tile = new JPanel();

                isWall[row][col] = (row == 0 || row == 9 || col == 0 || col == 9);

                tile.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                grid[row][col] = tile;
                add(tile);
            }
        }
    }

    private void drawGrid() {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (isWall[row][col]) {
                    grid[row][col].setBackground(Color.BLUE); // Wall
                } else if (row == playerRow && col == playerCol) {
                    grid[row][col].setBackground(Color.RED); // Player
                } else {
                    grid[row][col].setBackground(Color.WHITE); // Empty
                }
            }
        }
    }

    public void keyPressed(KeyEvent e) {
        int newRow = playerRow;
        int newCol = playerCol;

        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> newRow--;
            case KeyEvent.VK_DOWN -> newRow++;
            case KeyEvent.VK_LEFT -> newCol--;
            case KeyEvent.VK_RIGHT -> newCol++;
        }

        // Check bounds and if it's not a wall
        if (isValidMove(newRow, newCol)) {
            playerRow = newRow;
            playerCol = newCol;
            drawGrid();
        }
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < ROWS && col >= 0 && col < COLS && !isWall[row][col];
    }

    // Unused methods from KeyListener
    @Override public void keyTyped(KeyEvent e) {}
    @Override public void keyReleased(KeyEvent e) {}


    public static void main(String[] args) {
        Entity[][] format = new Entity[10][10];
        for (int i = 0; i < format.length; i++) {
            for (int j = 0; j < format.length; j++) {
                if(i == 0 || i == 9 || j == 0 || j == 9) {
                    format[i][j] = new Wall(i, j);
                } else {
                    format[i][j] = new EmptyTile(i, j);
                }
            }
        }
        new GameGrid();
    }
}