//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import javax.swing.*;
import Core.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Hello Swing!");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a label and add it to the frame
        JLabel label = new JLabel("Welcome to Swing!", SwingConstants.CENTER);
        frame.add(label);
        frame.setLocation(500, 500);
        frame.setTitle("I have no idea what I am doing...");

        // Make the frame visible
        frame.setVisible(true);
    }
}